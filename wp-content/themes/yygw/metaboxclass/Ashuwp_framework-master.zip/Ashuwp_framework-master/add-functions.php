<?php
/**
* Author: Ashuwp
* Author url: http://www.ashuwp.com
* Version: 5.0
**/

/**
* Add the following code into functions.php
**/
require get_template_directory() . '/ashuwp_framework/ashuwp_framework_core.php'; //加载ashuwp_framework框架
require get_template_directory() . '/ashuwp_framework/config-example.php'; //加载配置数据，config-example.php为配置范例。
